#from firebase  import firebase

#firebase = firebase.FirebaseAppication(https://smarticket-b0cb5.firebaseio.com/")
import firebase_admin
from firebase_admin import credentials
from firebase_admin import db

def initialize():

    cred = credentials.Certificate("/Users/Renan/Documents/Unisinos/0-PythonServer/SMserviceAccountKey.json")
    firebase_admin.initialize_app(cred, {
        'databaseURL': 'https://smarticket-b0cb5.firebaseio.com'
    })

    # As an admin, the app has access to read and write all data, regradless of Security Rules
    cardId = '1'
    userId = 'TYUm87UJFvMHSoeNLIwhP3xgF3J2'
    userRef = db.reference('users')
    user = userRef.child(userId)
    cards = user.child('cards').get()

    print(cards)
    print(type(cards))
    new_item = {'renan' : 'true'}
    new_item_l = ['renan' : 'true']
    if(type(cards)== list):
        cards.append(new_item_l)
    elif(type(cards)== dict):
        cards.update(new_item)
        for key, val in cards.items():
            print(key)
            print(val)
    print(cards)
    

    


    #     if key == 'users'
    #         for key, val in 
    #             ref2 = db.reference(ref + '/' key + '/' + val)
    #             snapshot2 = ref2.get()
    #             print (snapshot2)
    # a = 0
    # i = []
    # for keys in snapshot:
    #     a = a + 1
    #     print (keys)
    # print(ref.get())
    # print(a -1)
    # for key, value in snapshot:
    #     print(key)
    #     print(value)
    #     i.append(value)        
    #     a = a + 1
    # print(i)

initialize()