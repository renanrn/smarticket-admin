#!/usr/bin/env python3

from flask import Flask, request, jsonify, json
from gerencianet import Gerencianet

app = Flask(__name__)

@app.route('/')
def hello():
    return 'Bem vindo ao SmarTicket!'

@app.route('/', methods=['POST'])
def hello_post():
    name = request.form['name']
    amount = request.form['amount']
    value = request.form['value']
    value = value.replace(',','')
    value = value.replace('.','')
    token = request.form['payment_token']
    
    billingAddress = json.loads(request.form['billing_address'])
    billingAddress = billingAddress['billingAddress']

    user = json.loads(request.form['user'])
    user = user['user']
    
    charge_res = charge(name,amount,value)
    charge_id = charge_res['data']['charge_id']
    pay_res = pay(charge_id, token, billingAddress, user)

    #return jsonify(response=pay_res,status=200)
    #jsonify(response=billingAddress['billingAddress'],status=200)
    return jsonify(response=pay_res,status=200)
    
    #return 'Hello, {}'.format(upcase(nome)), 200

@app.errorhandler(404)
def page_not_found(error):
    return 'Página não encontrada', 404


def upcase(nome):
    return nome.upper()


options = {
    'client_id': 'Client_Id_0bac5973bde403a31c9618f3877dfcd3182a28a7',
    'client_secret': 'Client_Secret_212163ed29c78a8da6af4a8cbb403fc293202f69',
    'sandbox': True
}

def charge(name, amount, value):
    gn = Gerencianet(options)
    body = {
        'items': [{
            'name': name,
            'value': int(value),
            'amount': int(amount)
        }]
    }
    response =  gn.create_charge(body=body)
    print(response)
    return response

import dateutil.parser

def pay(charge_id, token, billingAddress, user):
    date = user['birth']
    birthParsed = dateutil.parser.parse(date)
    birthFormated = birthParsed.strftime('%Y-%m-%d')

    gn = Gerencianet(options)
    params = { 'id': charge_id }

    body = {
            'payment': {
                'credit_card': {
                    'installments': 1,
                    'payment_token': token,
                    'billing_address': {
                        'street': billingAddress['street'], 
                        'number': int(billingAddress['number']),
                        'neighborhood': billingAddress['neighborhood'],
                        'zipcode': billingAddress['zipcode'],
                        'city': billingAddress['city'],
                        'state': billingAddress['state'] 
                        },
                    'customer': {
                        'name': user['name'],
                        'email': user['email'],
                        'cpf': user['cpf'],
                        'birth': birthFormated,
                        'phone_number': user['phone_number']
                        }
                }
            }
        }
    response = gn.pay_charge(params=params, body=body)    
    print(response)
    return response


# import firebase_admin
# from firebase_admin import credentials
# from firebase_admin import db

# cred = credentials.Certificate("/Users/Renan/Documents/Unisinos/0-PythonServer/SMserviceAccountKey.json")
# firebase_admin.initialize_app(cred)

# # As an admin, the app has access to read and write all data, regradless of Security Rules
# ref = db.reference('restricted_access/secret_document')
# print(ref.get())
