eval "$(pyenv init -)"
pyenv shell 3.6.3
source gerencianet/bin/activate
python firebaseTest.py
