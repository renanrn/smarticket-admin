package com.invictus.smarticket;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class EventosDetalhesActivity extends AppCompatActivity
{
    private Button btnComprar;
    private TextView tvTitle, tvDate, tvLocal, tvDetails;
    private String idEvt;
    private Intent intent;
    private Bundle extras;
    private DatabaseReference mRef = FirebaseDatabase.getInstance().getReference("events");
    private DatabaseReference evtRef;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_eventos_detalhes);
        getSupportActionBar().hide();

        tvTitle = (TextView)findViewById(R.id.txtTitle);
        tvDate = (TextView)findViewById(R.id.txtDate);
        tvLocal = (TextView)findViewById(R.id.txtLocal);
        tvDetails = (TextView)findViewById(R.id.txtDetails);
        btnComprar = (Button)findViewById(R.id.btn_comprar);

        idEvt = getIntent().getExtras().getString("id_evt");
        evtRef = mRef.child(idEvt);
        evtRef.addListenerForSingleValueEvent(new ValueEventListener()
        {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot)
            {
                try
                {

                    tvTitle.setText(String.valueOf(dataSnapshot.child("title").getValue()));

                    String dateFb = String.valueOf(dataSnapshot.child("date").getValue());
                    if(!dateFb.equals("null"))
                    {
                        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
                        SimpleDateFormat targetFormat = new SimpleDateFormat("dd/MM/yyyy");
                        Date date = (Date) format.parse(dateFb);
                        tvDate.setText(tvDate.getText() + String.valueOf(targetFormat.format(date)));
                    }
                    else
                    {
                        tvDate.setText(tvDate.getText() + "Mais informações em breve.");
                    }

                    String localFb = String.valueOf(dataSnapshot.child("local").getValue());
                    if(!localFb.equals("null"))
                    {
                        tvLocal.setText(tvLocal.getText()+localFb);
                    }
                    else
                    {
                        tvLocal.setText(tvLocal.getText()+ "Mais informações em breve.");
                    }
                    String detailFb = String.valueOf(dataSnapshot.child("details").getValue());
                    detailFb = detailFb.replace("\\n", System.getProperty("line.separator"));
                    if(!localFb.equals("null"))
                    {
                        tvDetails.setText(tvDetails.getText()+detailFb);
                    }
                }
                catch (ParseException e){
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError)
            {

            }
        });
        btnComprar.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                Intent intent = new Intent(EventosDetalhesActivity.this, CompraDetalhes.class);
                intent.putExtra("id_evt", idEvt);
                EventosDetalhesActivity.this.startActivity(intent);
            }
        });
    }
}
