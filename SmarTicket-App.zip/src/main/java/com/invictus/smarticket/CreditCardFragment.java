package com.invictus.smarticket;

import android.app.Fragment;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

/**
 * Created by renan on 01/11/17.
 */

public class CreditCardFragment extends android.support.v4.app.Fragment
{
    public CreditCardFragment()
    {
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState)
    {
        View ccView = inflater.inflate(R.layout.fragment_credit_card, container, false);
        return super.onCreateView(inflater, container, savedInstanceState);
    }
}
