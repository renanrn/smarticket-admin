package com.invictus.smarticket;


import android.content.ContentValues;
import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;
import android.util.Pair;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.gson.JsonObject;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedWriter;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;

public class WebService
{
    private Context mContext;
    String URL_ws;
    Map<String, String> params_ws;
    JSONObject resp = new JSONObject();
    public Object Synchronize(String URL, Map<String, String> params, Context appContext) throws InterruptedException, ExecutionException
    {
        URL_ws = URL;
        params_ws = params;
        mContext = appContext;
        return new Sync(mContext).execute().get();

    }

    //-----------Métodos padrões de AsyncTask--------------------------
    private class Sync extends AsyncTask<String, Float, Object>
    {

        public Sync(Context context)
        {
            mContext = context;
        }

        @Override
        protected void onPreExecute()
        {
            super.onPreExecute();
            Log.i("pre", "Pre Execute");
        }

        @Override
        protected JSONObject doInBackground(String... params)
        {
            String url = URL_ws;

            StringRequest postRequest = new StringRequest(Request.Method.POST, url,
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            try {
                                JSONObject jsonResponse = new JSONObject(response);
                                resp = jsonResponse;
                                Log.d("JSON","JSON Response: "+jsonResponse.toString());

                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            error.printStackTrace();
                        }
                    }
            ) {

                @Override
                protected Map<String, String> getParams()
                {
                    /*Map<String, String>  params = new HashMap<>();
                    // the POST parameters:
                    params.put("token", token_ws);*/
                    return params_ws;
                }
            };
            Volley.newRequestQueue(mContext).add(postRequest);

            return resp;
        }

        @Override
        protected void onPostExecute(Object result)
        {
            super.onPostExecute(result);
            Log.i("pos", "Pos Execute");

        }

        protected void onProgressUpdate(Float... progress)
        {
            super.onProgressUpdate(progress);
            Log.i("makemachine", "onProgressUpdate(): " + String.valueOf(progress[0]));
        }

    }
    //----------------Fim dos Métodos padrões do AsyncTask---------------------
}