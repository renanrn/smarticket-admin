package com.invictus.smarticket;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.gson.Gson;
import com.invictus.smarticket.classes.BillingAddress;
import com.invictus.smarticket.classes.Cards;
import com.invictus.smarticket.classes.CreditCards;
import com.invictus.smarticket.classes.Itens;
import com.invictus.smarticket.classes.Users;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import br.com.gerencianet.gnsdk.config.Config;
import br.com.gerencianet.gnsdk.interfaces.IGnListener;
import br.com.gerencianet.gnsdk.lib.Endpoints;
import br.com.gerencianet.gnsdk.models.CreditCard;
import br.com.gerencianet.gnsdk.models.Error;
import br.com.gerencianet.gnsdk.models.Installment;
import br.com.gerencianet.gnsdk.models.PaymentData;
import br.com.gerencianet.gnsdk.models.PaymentToken;

public class ComandaDetalheActivity extends AppCompatActivity implements IGnListener
{
    private String userId, evtId, evtTitle, cardId, cardStatus, cardType;
    private TextView txtMyCardId, txtEvtIdCard, txtCardStatus, txtCardType;
    private Button btnDividir, btnPagarComanda;
    private ListView listV;
    private ArrayList<String> listIdCards = new ArrayList<>();
    private ArrayList<String> list = new ArrayList<>();
    private ArrayAdapter<String> adapter;
    private DatabaseReference userRef = FirebaseDatabase.getInstance().getReference("users");
    private DatabaseReference cardsRef = FirebaseDatabase.getInstance().getReference("cards");
    private DatabaseReference cardsRefObj = FirebaseDatabase.getInstance().getReference("cards");
    private DatabaseReference itensRef = FirebaseDatabase.getInstance().getReference("itens");
    private DatabaseReference itensSingleRef, billingRef, ccRef;
    private LinkedHashMap<String, String> mapItens = new LinkedHashMap<>();
    private Cards toCard = new Cards();
    private ArrayList<String> listItens = new ArrayList<>();
    private ArrayList<String> listItensQtd = new ArrayList<>();
    private boolean isActive = false;
    private ProgressDialog pDialog;
    private Context context = this;
    private List<Itens> lstItensGlobal = new ArrayList<>();
    private Itens toItens;
    private Users toUser = new Users();
    private Gson gson = new Gson();
    private Map<String, String> params = new HashMap<String, String>();
    private Config config;
    private Endpoints gnClient;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_comanda_detalhe);
        getSupportActionBar().hide();

        //GERÊNCIANET
        String GNAccountCode = getResources().getString(R.string.gn_account_code);
        config = new Config();
        config.setAccountCode(GNAccountCode);
        config.setSandbox(true);
        gnClient = new Endpoints(config, this);

        cardsRef.keepSynced(true);
        cardsRefObj.keepSynced(true);
        itensRef.keepSynced(true);

       pDialog = new ProgressDialog(context);
        pDialog.setTitle("Carregando...");
         pDialog.show();
        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            public void run() {
                pDialog.dismiss();
            }
        }, 2000);

        userId = getIntent().getExtras().getString("user_id");
        evtId = getIntent().getExtras().getString("evt_id");
        evtTitle = getIntent().getExtras().getString("evt_title");
        cardId = getIntent().getExtras().getString("card_id");

        txtEvtIdCard = (TextView) findViewById(R.id.txtEvtIdCard);
        txtMyCardId = (TextView) findViewById(R.id.txtMyCardId);
        txtCardType = (TextView) findViewById(R.id.txtCardType);
        txtCardStatus = (TextView) findViewById(R.id.txtCardStatus);
        btnDividir = (Button) findViewById(R.id.btnDividir);
        btnPagarComanda = (Button) findViewById(R.id.btnPagarComanda);
        listV = (ListView) findViewById(R.id.listviewItens);

        adapter = new ArrayAdapter<String>(this, R.layout.drawer_list_item, list);
        listV.setAdapter(adapter);

        txtMyCardId.setText("Comanda: " + cardId);
        txtEvtIdCard.setText("Evento: " + evtTitle);

        loadUserObject(userId);
        loadCardInfo();
        loadItensList();
        loadCardObject(cardId);

        btnDividir.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Intent intent = new Intent(ComandaDetalheActivity.this, QRCodeActivity.class);
                intent.putExtra("qr_string", cardId);
                ComandaDetalheActivity.this.startActivity(intent);
            }
        });
    }

    private void loadCardInfo()
    {
        cardsRef = FirebaseDatabase.getInstance().getReference("cards");
        cardsRef = cardsRef.child(cardId);
        cardsRef.addListenerForSingleValueEvent(new ValueEventListener()
        {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot)
            {
                for (DataSnapshot childs : dataSnapshot.getChildren())
                {
                    if (childs.getKey().toString().equals("type"))
                    {
                        txtCardType.setText("Tipo: " + childs.getValue().toString());
                        if (childs.getValue().toString().equals("Dividida"))
                        {
                            btnDividir.setText("Adicionar Divisor");
                        }
                        else
                        {
                            btnDividir.setText("Dividir Comanda");
                        }
                    }
                    if (childs.getKey().toString().equals("status"))
                    {
                        txtCardStatus.setText("Status: " + childs.getValue().toString());
                        if (childs.getValue().toString().equals("active"))
                        {
                            btnPagarComanda.setEnabled(true);
                            btnPagarComanda.setTextColor(Color.parseColor("#E2E2F9"));
                            btnDividir.setEnabled(true);
                            btnDividir.setTextColor(Color.parseColor("#E2E2F9"));
                        }
                        else
                        {
                            btnPagarComanda.setEnabled(false);
                            btnPagarComanda.setTextColor(Color.parseColor("#7f7f7f"));
                            btnDividir.setEnabled(false);
                            btnDividir.setTextColor(Color.parseColor("#7f7f7f"));
                        }
                    }
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError)
            {
            }
        });
    }

    private void loadItensList()
    {
        cardsRef = FirebaseDatabase.getInstance().getReference("cards");
        cardsRef = cardsRef.child(cardId).child("itens");
        cardsRef.addListenerForSingleValueEvent(new ValueEventListener()
        {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot)
            {
                for (DataSnapshot childs : dataSnapshot.getChildren())
                {
                    String key, value;
                    key = childs.getKey().toString();
                    value = childs.getValue().toString();
                    listItens.add(key);
                    listItensQtd.add(value);
                }
                for (int i = 0; i <= listItens.size() - 1; i++)
                {
                    String itemKey = listItens.get(i);
                    final String itemQtd = listItensQtd.get(i);

                    itensSingleRef = itensRef.child(itemKey);
                    itensSingleRef.addListenerForSingleValueEvent(new ValueEventListener()
                    {
                        @Override
                        public void onDataChange(DataSnapshot dataSnapshot)
                        {
                            String nameItem = "", priceItem = "";
                            for (DataSnapshot childs : dataSnapshot.getChildren())
                            {
                                if (childs.getKey().toString().equals("name"))
                                {
                                    nameItem = childs.getValue().toString();
                                }
                                if (childs.getKey().toString().equals("price"))
                                {
                                    priceItem = childs.getValue().toString();
                                }
                                if (nameItem != "" && priceItem != "")
                                {
                                    String linhaItem;
                                    linhaItem = nameItem + " | Qtd: " + itemQtd + " | R$ " + priceItem;
                                    list.add(linhaItem);
                                    adapter.notifyDataSetChanged();
                                }
                            }
                        }

                        @Override
                        public void onCancelled(DatabaseError databaseError)
                        {
                        }
                    });

                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError)
            {
            }
        });
    }

    protected void pagarComanda(View v)
    {
/*        if (toCard.getType().equals("Divivida"))
        {*/
            AlertDialog.Builder builder = new AlertDialog.Builder(context);
            builder.setTitle("Deseja finalizar comanda?")
                    .setMessage(
                            toCard.getType().equals("Dividida")
                                    ? "A comanda é dividida. Se prosseguir ela será finalizada para todos os participantes."
                                    : "Ao finalizar, a comanda será fechada e deverá ser realizado o pagamento.")
                    .setPositiveButton("Sim", new DialogInterface.OnClickListener()
                    {
                        @Override
                        public void onClick(DialogInterface dialog, int which)
                        {
                            ArrayList<String> array = new ArrayList<>();
                            for (int i = 0; i < toUser.getCreditCards().size(); i++)
                            {
                                array.add(toUser.getCreditCards().get(i).getBrandNumberFormat());
                            }
                            CharSequence[] itens = array.toArray(new CharSequence[array.size()]);

                            LayoutInflater inflater = ComandaDetalheActivity.this.getLayoutInflater();
                            View vv = inflater.inflate(R.layout.fragment_quantidade_ingressos, null);
                            AlertDialog.Builder builder = new AlertDialog.Builder(ComandaDetalheActivity.this);
                            builder.setView(vv)
                                    .setTitle("Escolha o cartão:")
                                    .setSingleChoiceItems(itens, -1, new DialogInterface.OnClickListener()
                                    {
                                        @Override
                                        public void onClick(DialogInterface dialog, int i)
                                        {
                                            try
                                            {
                                                // Inserindo parâmetros dos itens (nesse caso, somente o ingresso)
                                                String number = toUser.getCreditCards().get(i).getNumber();
                                                String cvv = toUser.getCreditCards().get(i).getCvv();
                                                String month = toUser.getCreditCards().get(i).getExpirationMonth();
                                                String year = toUser.getCreditCards().get(i).getExpirationYear();
                                                String brand = toUser.getCreditCards().get(i).getBrand();

                                                CreditCard creditCard = new CreditCard();
                                                creditCard.setCvv(cvv);
                                                creditCard.setNumber(number);
                                                creditCard.setExpirationMonth(month);
                                                creditCard.setExpirationYear("20" + year);
                                                creditCard.setBrand(brand.toLowerCase());

                                                gnClient.getPaymentToken(creditCard);

                                                dialog.dismiss();
                                                pDialog.show();

                                            }
                                            catch (Exception e)
                                            {
                                            }
                                        }
                                    });
                            builder.show();
                        }
                    })
                    .setNegativeButton("Não", new DialogInterface.OnClickListener()
                    {
                        @Override
                        public void onClick(DialogInterface dialog, int which)
                        {
                            dialog.dismiss();
                            Toast.makeText(ComandaDetalheActivity.this, "Pagamento cancelado.", Toast.LENGTH_SHORT).show();
                        }
                    })
                    .show();
/*        }
        else
        {
            AlertDialog.Builder builder = new AlertDialog.Builder(context);
            builder.setTitle("Deseja finalizar comanda?")
                    .setMessage("Ao finalizar, a comanda será fechada e deverá ser realizado o pagamento.")
                    .setPositiveButton("Sim", new DialogInterface.OnClickListener()
                    {

                    })
                    .setNegativeButton("Não", new DialogInterface.OnClickListener()
                    {
                        @Override
                        public void onClick(DialogInterface dialog, int which)
                        {
                            dialog.dismiss();
                            Toast.makeText(ComandaDetalheActivity.this, "Pagamento cancelado.", Toast.LENGTH_SHORT).show();
                        }
                    })
                    .show();
        }*/
    }

    @Override
    public void onInstallmentsFetched(PaymentData paymentData)
    {
        ArrayList<Installment> installments = (ArrayList<Installment>) paymentData.getInstallments();
        for (Installment installment : installments)
        {
            Log.e("GerenciaNet Response: ", installment.getValue().toString());
        }
    }

    @Override
    public void onError(Error error)
    {
        View view = findViewById(R.id.response_layout);
        view.setVisibility(View.VISIBLE);

        String errorMsg = "Code: " + error.getCode() + " Message: " + error.getMessage();

        TextView textView = (TextView) findViewById(R.id.response_text);
        textView.setText(errorMsg);
    }

    @Override
    public void onPaymentTokenFetched(PaymentToken paymentToken)
    {
        pDialog.dismiss();

//        txtResponse.setText("GerenciaNet Payment token: " + paymentToken.getHash());

        // Inserindo parâmetros do token
        params.put("payment_token", paymentToken.getHash());
        // Inserindo parâmetros do usuário
        params.put("user", gson.toJson(toUser));

        // Inserindo parâmetros do endereço
        BillingAddress ba = new BillingAddress();
        ba = toUser.getBillingAddress();
        params.put("billing_address", gson.toJson(ba));

        // Inserindo parâmetros da comanda (com a lista dos itens)
        params.put("card", gson.toJson(toCard));

        sendMessage(params);
    }

    private void sendMessage(Map<String, String> params)
    {
        try
        {

            JSONObject jj = new JSONObject();
            ComandaDetalheActivity.PagarWS pagar = new ComandaDetalheActivity.PagarWS();
            jj = pagar.execute().get();

            ComprasConfirmacaoFragment my_dialog = new ComprasConfirmacaoFragment();
            my_dialog.show(getSupportFragmentManager(), "my_dialog");

//            gravarEvento();
        }
        catch (Exception e)
        {
            Log.d("ErroWS", "Erro no WebService: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private class PagarWS extends AsyncTask<Void, Void, JSONObject>
    {
        String urlDividida = "http://192.168.1.16:5000/PagarComandaDividida";
        String urlParticular = "http://192.168.1.16:5000/PagarComandaParticular";
        ProgressDialog dialog;
        JSONObject resp = new JSONObject();
        String URL_ws = toCard.getType().equals("Dividida") ? urlDividida : urlParticular ;
        Map<String, String> params_ws = params;

        @Override
        protected void onPreExecute()
        {
            dialog = new ProgressDialog(context);
            dialog.setTitle("Pagando comanda...");
            dialog.show();
            super.onPreExecute();
        }

        @Override
        protected void onPostExecute(JSONObject jsonObject)
        {
            dialog.dismiss();
            super.onPostExecute(jsonObject);
        }

        @Override
        protected JSONObject doInBackground(Void... voids)
        {
            String url = URL_ws;

            StringRequest postRequest = new StringRequest(Request.Method.POST, url,
                    new Response.Listener<String>()
                    {
                        @Override
                        public void onResponse(String response)
                        {
                            try
                            {
                                JSONObject jsonResponse = new JSONObject(response);
                                resp = new JSONObject(response);
                                Log.d("JSON", "JSON Response: " + jsonResponse.toString());

                            }
                            catch (JSONException e)
                            {
                                e.printStackTrace();
                            }
                        }
                    },
                    new Response.ErrorListener()
                    {
                        @Override
                        public void onErrorResponse(VolleyError error)
                        {
                            error.printStackTrace();
                        }
                    }
            )
            {

                @Override
                protected Map<String, String> getParams()
                {
                    return params_ws;
                }
            };
            MySingleton.getInstance(context).addToRequestQueue(postRequest);
//            Volley.newRequestQueue(context).add(postRequest);
            return resp;
        }
    }



    // ################################################ MÉTODOS PARA LOADS DE OBJETOS #####################################~ç´
    private void loadCardObject(final String cardObjId)
    {
        cardsRefObj = cardsRefObj.child(cardObjId);
        cardsRefObj.addListenerForSingleValueEvent(new ValueEventListener()
        {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot)
            {
                String evtIdCard, status, cardType;
                for (DataSnapshot childs : dataSnapshot.getChildren())
                {
                    toCard.setId(cardId);
                    if (childs.getKey().toString().equals("event"))
                    {
                        toCard.setEvent(childs.getValue().toString());
                    }
                    if (childs.getKey().toString().equals("status"))
                    {
                        toCard.setStatus(childs.getValue().toString());
                    }
                    if (childs.getKey().toString().equals("origin"))
                    {
                        toCard.setOrigin(childs.getValue().toString());
                    }
                    if (childs.getKey().toString().equals("type"))
                    {
                        toCard.setType(childs.getValue().toString());
                    }
                    if (childs.getKey().toString().equals("itens"))
                    {
                        for (int i = 0; i <= listItens.size() - 1; i++)
                        {
                            final String itemKey = listItens.get(i);
                            final String itemQtd = listItensQtd.get(i);

                            itensSingleRef = itensRef.child(itemKey);
                            itensSingleRef.addListenerForSingleValueEvent(new ValueEventListener()
                            {
                                @Override
                                public void onDataChange(DataSnapshot dataSnapshot)
                                {
                                    String itName = "", itPrice = "";
                                    toItens = new Itens();
                                    for (DataSnapshot childs : dataSnapshot.getChildren())
                                    {
                                        if (childs.getKey().toString().equals("name"))
                                        {
                                            itName = childs.getValue().toString();
                                            toItens.setName(childs.getValue().toString());
                                        }
                                        if (childs.getKey().toString().equals("price"))
                                        {
                                            itPrice = childs.getValue().toString();
                                            toItens.setValue(Double.valueOf(childs.getValue().toString()));
                                        }
                                        if (!itName.equals("") && !itPrice.equals(""))
                                        {
                                            toItens.setAmount(Integer.valueOf(itemQtd));
                                            toItens.setId(itemKey);
                                            lstItensGlobal.add(toItens);
                                        }
                                    }
                                }

                                @Override
                                public void onCancelled(DatabaseError databaseError)
                                {
                                }
                            });
                            toCard.setItens(lstItensGlobal);
                        }
                    }
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError)
            {
            }
        });
    }

    private void loadUserObject(String idUser)
    {
        userRef = userRef.child(idUser);
        userRef.addListenerForSingleValueEvent(new ValueEventListener()
        {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot)
            {
                for (DataSnapshot childs : dataSnapshot.getChildren())
                {
                    if (childs.getKey().equals("name"))
                    {
                        toUser.setName(childs.getValue().toString());
                    }
                    if (childs.getKey().equals("email"))
                    {
                        toUser.setEmail(childs.getValue().toString());
                    }
                    if (childs.getKey().equals("cpf"))
                    {
                        toUser.setCpf(childs.getValue().toString());
                    }
                    if (childs.getKey().equals("birth"))
                    {
                        toUser.setBirth(childs.getValue().toString());
                    }
                    if (childs.getKey().equals("phone_number"))
                    {
                        toUser.setPhoneNumber(childs.getValue().toString());
                    }
                    if (childs.getKey().equals("provider"))
                    {
                        toUser.setProvider(childs.getValue().toString());
                    }
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError)
            {
            }
        });
        billingRef = userRef.child("billing_address");
        billingRef.addListenerForSingleValueEvent(new ValueEventListener()
        {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot)
            {
                for (DataSnapshot childs : dataSnapshot.getChildren())
                {
                    if (childs.getKey().equals("street"))
                    {
                        toUser.getBillingAddress().setStreet(childs.getValue().toString());
                    }
                    if (childs.getKey().equals("number"))
                    {
                        toUser.getBillingAddress().setNumber(childs.getValue().toString());
                    }
                    if (childs.getKey().equals("neighborhood"))
                    {
                        toUser.getBillingAddress().setNeighborhood(childs.getValue().toString());
                    }
                    if (childs.getKey().equals("zipcode"))
                    {
                        toUser.getBillingAddress().setZipcode(childs.getValue().toString());
                    }
                    if (childs.getKey().equals("city"))
                    {
                        toUser.getBillingAddress().setCity(childs.getValue().toString());
                    }
                    if (childs.getKey().equals("state"))
                    {
                        toUser.getBillingAddress().setState(childs.getValue().toString());
                    }
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError)
            {
            }
        });
        //        ################################################################### Mapeando o cartao de crédito ########################################
        ccRef = userRef.child("credit_cards");
        ccRef.addListenerForSingleValueEvent(new ValueEventListener()
        {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot)
            {
                List<CreditCards> card = new ArrayList<>();
                for (DataSnapshot ds : dataSnapshot.getChildren())
                {
                    CreditCards cardSM = new CreditCards();
                    for (DataSnapshot childs : ds.getChildren())
                    {
                        if (childs.getKey().equals("brand"))
                        {
                            cardSM.setBrand(childs.getValue().toString());
                        }
                        if (childs.getKey().equals("number"))
                        {
                            cardSM.setNumber(childs.getValue().toString());
                        }
                        if (childs.getKey().equals("cvv"))
                        {
                            cardSM.setCvv(childs.getValue().toString());
                        }
                        if (childs.getKey().equals("expirationMonth"))
                        {
                            cardSM.setExpirationMonth(childs.getValue().toString());
                        }
                        if (childs.getKey().equals("expirationYear"))
                        {
                            cardSM.setExpirationYear(childs.getValue().toString());
                        }

                    }
                    card.add(cardSM);
                }
                toUser.setCreditCards(card);
            }

            @Override
            public void onCancelled(DatabaseError databaseError)
            {

            }
        });

    }
}
