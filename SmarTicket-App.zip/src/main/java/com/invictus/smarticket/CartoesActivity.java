package com.invictus.smarticket;

import android.content.DialogInterface;
import android.graphics.Color;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v7.app.AlertDialog;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import com.devmarvel.creditcardentry.library.CardValidCallback;
import com.devmarvel.creditcardentry.library.CreditCard;
import com.devmarvel.creditcardentry.library.CreditCardForm;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.invictus.smarticket.classes.CreditCards;
import com.invictus.smarticket.classes.Users;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class CartoesActivity extends FragmentActivity implements Serializable
{
    private static final String TAG = "CartoesActivity";
    private Users userSM;
    private Button btnAddCard, btnOk;
    private ListView listV;
    private CreditCards cardSM = new CreditCards();
    private DatabaseReference ref = FirebaseDatabase.getInstance().getReference("users");
    private DatabaseReference userRef;
    private DatabaseReference ccRef;
    private CreditCardForm form;
    private ArrayAdapter<String> adapter;
    private ArrayList<String> list = new ArrayList<>();

    CardValidCallback cardValidCallback = new CardValidCallback()
    {
        @Override
        public void cardValid(CreditCard creditCard)
        {
            Log.d(TAG, "valid card: " + creditCard);
            Toast.makeText(CartoesActivity.this, "Cartão válido", Toast.LENGTH_SHORT).show();

            btnOk.setEnabled(true);
            btnOk.setTextColor(Color.parseColor("#E2E2F9"));
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cartoes);

        btnOk = (Button) findViewById(R.id.btnOk);
        btnOk.setEnabled(false);
        btnOk.setTextColor(Color.parseColor("#7f7f7f"));

        listV = (ListView) findViewById(R.id.listviewCC);
        adapter = new ArrayAdapter<String>(this, R.layout.drawer_list_item, list);
        listV.setAdapter(adapter);

        form = (CreditCardForm) findViewById(R.id.credit_card_form);
        form.setOnCardValidCallback(cardValidCallback);


        userSM = (Users) getIntent().getSerializableExtra("userSM");
        userRef = ref.child(userSM.getId());

        btnOk.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                if (form.isCreditCardValid())
                {
                    CreditCard card = form.getCreditCard();

                    cardSM.setNumber(card.getCardNumber().toString().replace(" ", ""));
                    cardSM.setBrand(card.getCardType().toString());
                    String expM = card.getExpMonth().toString();
                    expM = expM.length() == 1 ? "0" + expM : expM;
                    cardSM.setExpirationMonth(expM);
                    cardSM.setExpirationYear(card.getExpYear().toString());
                    cardSM.setCvv(card.getSecurityCode());

                    String key = userRef.child("credit_card").push().getKey();
                    Map<String, Object> cardValues = cardSM.toMap();

                    Map<String, Object> childUpdates = new HashMap<>();
                    childUpdates.put("/credit_cards/" + key, cardValues);

                    userRef.updateChildren(childUpdates);
                }
                else
                {
                    btnOk.setEnabled(false);
                    btnOk.setTextColor(Color.parseColor("#7f7f7f"));
                }
            }

        });

        form.setOnFocusChangeListener(new View.OnFocusChangeListener()
        {
            @Override
            public void onFocusChange(View v, boolean hasFocus)
            {
                Log.d(TAG, v.getClass().getSimpleName() + " " + (hasFocus ? "gained" : "lost") + " focus. card valid: " + form.isCreditCardValid());
            }
        });

        ccRef = userRef.child("credit_cards");
        ccRef.addChildEventListener(new ChildEventListener()
        {
            @Override
            public void onChildAdded(DataSnapshot dataSnapshot, String s)
            {
                String brand = "", number = "";
                for (DataSnapshot childs : dataSnapshot.getChildren())
                {
                    if (childs.getKey().equals("brand"))
                    {
                        brand = childs.getValue().toString();
                    }
                    if (childs.getKey().equals("number"))
                    {
                        number = childs.getValue().toString();
                        number = number.substring(number.length() - 4, number.length());
                        number = "#### #### #### " + number;
                    }
                    if (brand.length() > 0 && number.length() > 0)
                    {
                        String lineCC = brand + " - " + number;
                        list.add(lineCC);
                        adapter.notifyDataSetChanged();
                    }
                }
            }

            @Override
            public void onChildRemoved(DataSnapshot dataSnapshot)
            {
                for (DataSnapshot childs : dataSnapshot.getChildren())
                {
                    if (childs.getKey().equals("number"))
                    {
                        list.remove(childs.getValue());
                        adapter.notifyDataSetChanged();
                    }
                }
            }

            @Override
            public void onChildChanged(DataSnapshot dataSnapshot, String s)
            {
            }

            @Override
            public void onChildMoved(DataSnapshot dataSnapshot, String s)
            {
            }

            @Override
            public void onCancelled(DatabaseError databaseError)
            {
            }
        });
        listV.setOnItemClickListener(new AdapterView.OnItemClickListener()
        {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id)
            {
                final int pos = position;
                new AlertDialog.Builder(CartoesActivity.this)
                        .setTitle("Confirmação")
                        .setMessage("Deseja excluir o cartão?")
                        .setPositiveButton("Sim", new DialogInterface.OnClickListener()
                        {
                            public void onClick(DialogInterface dialog, int whichButton)
                            {
                                list.remove(pos);
                                adapter.notifyDataSetChanged();
                            }
                        })
                        .setNegativeButton("Não", null).show();
            }
        });
    }

    public static class CCFragment extends Fragment
    {
        @Override
        public View onCreateView(LayoutInflater inflater, ViewGroup container,
                                 Bundle savedInstanceState)
        {
            View v = inflater.inflate(R.layout.fragment_credit_card, container, false);
            // Retrieve the text editor and tell it to save and restore its state.
            // Note that you will often set this in the layout XML, but since
            // we are sharing our layout with the other fragment we will customize it here.
            return v;
        }
    }
}
