package com.invictus.smarticket;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class MeusEventosActivity extends AppCompatActivity
{
    private FirebaseAuth mAuth = FirebaseAuth.getInstance();
    private DatabaseReference mRef, evtRef;
    private ArrayAdapter<String> adapter;
    private ListView listV;
    private String userId, evtId, evtTitle;
    private ArrayList<String> list = new ArrayList<>(), evtList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_eventos_list);
        listV = (ListView) findViewById(R.id.listview);
        getSupportActionBar().hide();
        userId = getIntent().getExtras().getString("user_id");

        adapter = new ArrayAdapter<String>(this, R.layout.drawer_list_item, list);
        listV.setAdapter(adapter);

        mRef = FirebaseDatabase.getInstance().getReference("users").child(userId).child("events");
        mRef.addListenerForSingleValueEvent(new ValueEventListener()
        {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot)
            {
                for (DataSnapshot childs : dataSnapshot.getChildren())
                {
                    evtList.add(childs.getKey().toString());
                }
                listarMeusEvt();
            }

            @Override
            public void onCancelled(DatabaseError databaseError)
            {
            }
        });

        listV.setOnItemClickListener(new AdapterView.OnItemClickListener()
        {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int i, long id)
            {
                Intent intent = new Intent(MeusEventosActivity.this, MeusEventosDetalhesActivity.class);
                intent.putExtra("user_id",userId);

                evtId = evtList.get(i);
                intent.putExtra("evt_id",evtId);

                evtTitle = list.get(i).toString();
                intent.putExtra("evt_title",evtTitle);

                MeusEventosActivity.this.startActivity(intent);
            }
        });

    }

    public void listarMeusEvt()
    {
        for(String s : evtList)
        {
            evtRef = FirebaseDatabase.getInstance().getReference("events").child(s);
            evtRef.addListenerForSingleValueEvent(new ValueEventListener()
            {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot)
                {
                    for (DataSnapshot childs : dataSnapshot.getChildren())
                    {
                        if(childs.getKey().equals("title"))
                        {
                            list.add(childs.getValue().toString());
                            adapter.notifyDataSetChanged();
                        }
                    }
                }

                @Override
                public void onCancelled(DatabaseError databaseError)
                {
                }
            });
        }
    }
}
