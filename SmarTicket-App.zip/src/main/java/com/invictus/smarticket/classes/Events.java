package com.invictus.smarticket.classes;

/**
 * Created by renan on 24/08/17.
 */

public class Events
{
    private String Id;
    private String Title;
    private String Data;
    private String Local;
    private String Type;
    private String Tickets;
    private String Price;

    public Events()
    {
    }

    public Events(String id,String title, String data, String local, String type)
    {
        this.Id = id;
        this.Title = title;
        this.Data = data;
        this.Local = local;
        this.Type = type;
    }

    public Events(String id, String title, String data, String local, String type, String tickets, String price)
    {
        Id = id;
        Title = title;
        Data = data;
        Local = local;
        Type = type;
        Tickets = tickets;
        Price = price;
    }

    public String getTitle()
    {
        return Title;
    }

    public void setTitle(String title)
    {
        this.Title = title;
    }

    public String getData()
    {
        return Data;
    }

    public void setData(String data)
    {
        this.Data = data;
    }

    public String getLocal()
    {
        return Local;
    }

    public String getId() { return Id; }

    public void setId(String id) { Id = id; }

    public void setLocal(String local)
    {
        this.Local = local;
    }

    public String getType()
    {
        return Type;
    }

    public void setType(String type)
    {
        this.Type = type;
    }

    public String getTickets(){return Tickets;}

    public void setTickets(String tickets) { Tickets = tickets; }

    public String getPrice() { return Price; }

    public void setPrice(String price) { Price = price; }
}
