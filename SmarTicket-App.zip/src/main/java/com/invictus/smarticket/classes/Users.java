package com.invictus.smarticket.classes;

import java.io.Serializable;
import java.util.List;

/**
 * Created by renan on 26/09/17.
 */

public class Users implements Serializable
{
    private String Id;
    private String Name;
    private String Birth;
    private String Email;
    private String Provider;
    private String Cpf;
    private String PhoneNumber;
//    private Map<String,Boolean> String;
    private com.invictus.smarticket.classes.BillingAddress BillingAddress;
    private List<CreditCards> CreditCards;
    private List<Cards> Cards;

    public Users(){}

    public Users(String id, String name, String birth, String email, String provider, String cpf, String phoneNumber, com.invictus.smarticket.classes.BillingAddress billingAddress, List<com.invictus.smarticket.classes.CreditCards> creditCards, List<com.invictus.smarticket.classes.Cards> cards)
    {
        Id = id;
        Name = name;
        Birth = birth;
        Email = email;
        Provider = provider;
        Cpf = cpf;
        PhoneNumber = phoneNumber;
        BillingAddress = billingAddress;
        CreditCards = creditCards;
        Cards = cards;
    }

    public Users(String id, String name, String birth, String email, String provider)
    {
        Id = id;
        Name = name;
        Birth = birth;
        Email = email;
        Provider = provider;
    }

    public Users(String id, String name, String birth, String email, String provider, String phoneNumber)
    {
        Id = id;
        Name = name;
        Birth = birth;
        Email = email;
        Provider = provider;
        PhoneNumber = phoneNumber;
    }

    public Users(String id, String name, String birth, String email, String provider, String cpf, String phoneNumber, com.invictus.smarticket.classes.BillingAddress billingAddress)
    {
        Id = id;
        Name = name;
        Birth = birth;
        Email = email;
        Provider = provider;
        Cpf = cpf;
        PhoneNumber = phoneNumber;
        BillingAddress = billingAddress;
    }

    //    public Map<String, Boolean> getEvents()
//    {
//        return String;
//    }

//    public void setEvents(Map<String, Boolean> events)
//    {
//        String = events;
//    }

    public String getId()
    {
        return Id;
    }

    public void setId(String id)
    {
        Id = id;
    }

    public String getName()
    {
        return Name;
    }

    public void setName(String name)
    {
        Name = name;
    }

    public String getBirth()
    {
        return Birth;
    }

    public void setBirth(String birth)
    {
        Birth = birth;
    }

    public String getEmail()
    {
        return Email;
    }

    public void setEmail(String email)
    {
        Email = email;
    }

    public String getProvider()
    {
        return Provider;
    }

    public void setProvider(String provider)
    {
        Provider = provider;
    }

    public String getCpf() { return Cpf; }

    public void setCpf(String cpf) { Cpf = cpf; }

    public String getPhoneNumber() { return PhoneNumber; }

    public void setPhoneNumber(String phoneNumber) { PhoneNumber = phoneNumber; }

    public com.invictus.smarticket.classes.BillingAddress getBillingAddress()
    {
        if(BillingAddress == null) BillingAddress = new BillingAddress();
        return BillingAddress;
    }

    public void setBillingAddress(com.invictus.smarticket.classes.BillingAddress billingAddress)
    {
        BillingAddress = billingAddress;
    }

    /*public com.invictus.smarticket.classes.CreditCards getCreditCards()
    {
        return CreditCards;
    }

    public void setCreditCards(com.invictus.smarticket.classes.CreditCards cards)
    {
        CreditCards = cards;
    }
*/

    public List<CreditCards> getCreditCards()
    {
        return CreditCards;
    }

    public void setCreditCards(List<CreditCards> creditCards)
    {
        CreditCards = creditCards;
    }

    public List<com.invictus.smarticket.classes.Cards> getCards()
    {
        return Cards;
    }

    public void setCards(List<com.invictus.smarticket.classes.Cards> cards)
    {
        Cards = cards;
    }

    @Override
    public String toString()
    {
        return "{\"user\":{\"" +
            "id\":\""+ Id +
            "\",\"name\":\""+ Name +
            "\",\"birth\":\""+ Birth +
            "\",\"email\":\""+ Email +
            "\",\"provider\":\""+ Provider +
            "\",\"cpf\":\""+ Cpf +
            "\",\"phone_number\":\""+ PhoneNumber +
            "\"}}";
    }
}
