package com.invictus.smarticket.classes;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by renan on 31/10/17.
 */

public class CreditCards
{
    private String Name;
    private String Number;
    private String Brand;
    private String ExpirationMonth;
    private String ExpirationYear;
    private String Cvv;

    public CreditCards()
    {
    }

    public CreditCards(String name, String number, String brand, String expirationMonth, String expirationYear, String cvv)
    {
        Name = name;
        Number = number;
        Brand = brand;
        ExpirationMonth = expirationMonth;
        ExpirationYear = expirationYear;
        Cvv = cvv;
    }

    public String getName()
    {
        return Name;
    }

    public void setName(String name)
    {
        Name = name;
    }

    public String getNumber()
    {
        return Number;
    }

    public void setNumber(String number)
    {
        Number = number;
    }

    public String getBrand()
    {
        return Brand;
    }

    public void setBrand(String brand)
    {
        Brand = brand;
    }

    public String getExpirationMonth()
    {
        return ExpirationMonth;
    }

    public void setExpirationMonth(String expirationMonth)
    {
        ExpirationMonth = expirationMonth;
    }

    public String getExpirationYear()
    {
        return ExpirationYear;
    }

    public void setExpirationYear(String expirationYear)
    {
        ExpirationYear = expirationYear;
    }

    public String getCvv()
    {
        return Cvv;
    }

    public void setCvv(String cvv)
    {
        Cvv = cvv;
    }

    @Override
    public String toString()
    {
        return "{\"card\":{\"" +
                "name\":\""+ Name +
                "\",\"number\":\""+ Number +
                "\",\"brand\":\""+ Brand +
                "\",\"expirationMonth\":\""+ ExpirationMonth +
                "\",\"expirationYear\":\""+ ExpirationYear +
                "\",\"cvv\":\""+ Cvv +
                "\"}}";
    }

    public Map<String, Object> toMap() {
        HashMap<String, Object> result = new HashMap<>();
        result.put("name", Name);
        result.put("number", Number);
        result.put("brand", Brand);
        result.put("expirationMonth", ExpirationMonth);
        result.put("expirationYear", ExpirationYear);
        result.put("cvv", Cvv);

        return result;
    }
    public String getBrandNumberFormat()
    {
        return Brand + " - ...#### #### " +
                Number.substring(Number.length() - 4, Number.length());
    }
}
