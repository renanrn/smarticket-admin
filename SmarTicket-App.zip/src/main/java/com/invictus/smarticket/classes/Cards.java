package com.invictus.smarticket.classes;

import java.util.List;

/**
 * Created by renan on 09/11/17.
 */

public class Cards
{
    private java.lang.String Id;
    private java.lang.String Status;
    private java.lang.String Type;
    private java.lang.String Origin;
    private String Event;
    private List<Users> Users;
    private List<Itens> Itens;

    public Cards()
    {
    }

    public Cards(java.lang.String id, java.lang.String status, java.lang.String type, java.lang.String origin, String event, List<com.invictus.smarticket.classes.Users> users, List<com.invictus.smarticket.classes.Itens> itens)
    {
        Id = id;
        Status = status;
        Type = type;
        Origin = origin;
        Event = event;
        Users = users;
        Itens = itens;
    }

    public java.lang.String getId()
    {
        return Id;
    }

    public void setId(java.lang.String id)
    {
        Id = id;
    }

    public java.lang.String getStatus()
    {
        return Status;
    }

    public void setStatus(java.lang.String status)
    {
        Status = status;
    }

    public java.lang.String getType()
    {
        return Type;
    }

    public void setType(java.lang.String type)
    {
        Type = type;
    }

    public java.lang.String getOrigin() { return Origin; }

    public void setOrigin(java.lang.String origin) { Origin = origin; }

    public List<Users> getUsers()
    {
        return Users;
    }

    public void setUsers(List<Users> users)
    {
        Users = users;
    }

    public List<Itens> getItens()
    {
        return Itens;
    }

    public void setItens(List<Itens> itens)
    {
        Itens = itens;
    }

    public String getEvent() { return Event; }

    public void setEvent(String event) { Event = event; }

    @Override
    public java.lang.String toString()
    {
        return "{\"cards\":{\"" +
                "id\":\""+ Id +
                "\",\"status\":\""+ Status +
                "\",\"type\":\""+ Type +
                "\",\"origin\":\""+ Origin +
                "\",\"event\":\""+ Event +
                "\",\"itens\":\""+ Itens.toString() +
                "\"}}";
    }
}
