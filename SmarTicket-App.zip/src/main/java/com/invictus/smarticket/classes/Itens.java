package com.invictus.smarticket.classes;

/**
 * Created by renan on 08/11/17.
 */

public class Itens
{
    private String id;
    private String name;
    private String description;
    private int amount;
    private double value;

    public Itens() {}

    public Itens(String name, int amount, double value)
    {
        this.name = name;
        this.amount = amount;
        this.value = value;
    }

    public Itens(String id, String name, String description, int amount, double value)
    {
        this.id = id;
        this.name = name;
        this.description = description;
        this.amount = amount;
        this.value = value;
    }

    public String getId()
    {
        return id;
    }

    public void setId(String id)
    {
        this.id = id;
    }

    public String getName()
    {
        return name;
    }

    public void setName(String name)
    {
        this.name = name;
    }

    public String getDescription()
    {
        return description;
    }

    public void setDescription(String description)
    {
        this.description = description;
    }

    public int getAmount()
    {
        return amount;
    }

    public void setAmount(int amount)
    {
        this.amount = amount;
    }

    public double getValue()
    {
        return value;
    }
    public String getValueStr()
    {
        String valueStr = String.valueOf(value);
        valueStr = valueStr.replace(".","");
        valueStr = valueStr.replace(",","");
        return valueStr;
    }

    public void setValue(double value)
    {
        this.value = value;
    }

    @Override
    public String toString()
    {
        /*return "{\"itens\":{\"" +
                "id\":\""+ id +
                "\",\"name\":\""+ name +
                "\",\"description\":\""+ description +
                "\",\"amount\":\""+ String.valueOf(amount) +
                "\",\"price\":\""+ String.valueOf(value) +
                "\"}}";*/
        return "{\"itens\":{\"" +
                "id\":\""+ id +
                "\",\"name\":\""+ name +
                "\",\"description\":\""+ description +
                "\",\"amount\":\""+ String.valueOf(amount) +
                "\",\"value\":\""+ String.valueOf(value) +
                "\"}}";

    }
}
