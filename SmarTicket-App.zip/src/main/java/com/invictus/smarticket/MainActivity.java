package com.invictus.smarticket;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.facebook.AccessToken;
import com.facebook.CallbackManager;
import com.facebook.FacebookCallback;
import com.facebook.FacebookException;
import com.facebook.GraphRequest;
import com.facebook.GraphResponse;
import com.facebook.Profile;
import com.facebook.ProfileTracker;
import com.facebook.login.LoginManager;
import com.facebook.login.LoginResult;
import com.facebook.login.widget.LoginButton;
import com.facebook.login.widget.ProfilePictureView;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FacebookAuthProvider;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.invictus.smarticket.classes.Users;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.Serializable;

public class MainActivity extends AppCompatActivity implements Serializable
{

    private static final String TAG = "FacebookLogin";
    private LoginButton btnLoginFB;
    private ProfilePictureView imgProfileFB;
    private TextView tvBemVindo;
    private Button btnListarEventos, btnMeusEventos, btnMeuQrCode, btnCameraDecoder, btnGerenciarCartoes;
    //private TextView mStatusTextView;
    //private TextView mDetailTextView;
    private FirebaseAuth mAuth;
    private ProfileTracker mProfileTracker;
    private CallbackManager mCallbackManager;
    private String id, name, email, number, provider, birthday;
    private WebService ws = new WebService();
    private Users userSM;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //INSTÂNCIA DE OBJETOS DA TELA
        btnLoginFB = (LoginButton) findViewById(R.id.login_button);
        imgProfileFB = (ProfilePictureView) findViewById(R.id.profile_picture);
        btnListarEventos = (Button) findViewById(R.id.btn_listar_eventos);
        btnMeusEventos = (Button) findViewById(R.id.btn_meus_eventos);
        btnMeuQrCode = (Button) findViewById(R.id.btn_gerar_meu_qrcode);
        btnCameraDecoder = (Button) findViewById(R.id.btn_camera_qrcode);
        btnGerenciarCartoes = (Button)findViewById(R.id.btn_cartoes);
        tvBemVindo = (TextView)findViewById(R.id.txtBemVindo);
        GerenciaNetSM gn = new GerenciaNetSM();

        getSupportActionBar().hide();
        //PERMISSÕES DO BOTÃO LOGIN
        btnLoginFB.setReadPermissions("email", "public_profile", "pages_messaging_phone_number", "user_birthday");

        mAuth = FirebaseAuth.getInstance();

        mCallbackManager = CallbackManager.Factory.create();

        btnLoginFB.registerCallback(mCallbackManager, new FacebookCallback<LoginResult>()
        {

            @Override
            public void onSuccess(LoginResult loginResult)
            {
                Log.d(TAG, "facebook:onSuccess:" + loginResult);
                handleFacebookAccessToken(loginResult.getAccessToken());
            }

            @Override
            public void onCancel()
            {
                Log.d(TAG, "facebook:onCancel");
                updateUI();
            }

            @Override
            public void onError(FacebookException error)
            {
                Log.d(TAG, "facebook:onError", error);
                updateUI();
            }
        });

        // ############ PROFILE TRACKER FACEBOOK ############

        mProfileTracker = new ProfileTracker()
        {
            @Override
            protected void onCurrentProfileChanged(Profile oldProfile, Profile currentProfile)
            {
                updateUI();
                mProfileTracker.stopTracking();
            }
        };
        //BOTÕES #######################
        // ############ LISTAR EVENTOS ############
        btnListarEventos.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                Intent activityChangeIntent = new Intent(MainActivity.this, EventosListActivity.class);
                MainActivity.this.startActivity(activityChangeIntent);
            }
        });
        // ############ QR CODE ############
        btnMeuQrCode.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                Intent intent = new Intent(MainActivity.this, QRCodeActivity.class);
                FirebaseUser user = mAuth.getCurrentUser();
                id = user.getUid();
                intent.putExtra("qr_string",id.toString());
                MainActivity.this.startActivity(intent);
            }
        });
        // ############ CAMERA QR CODE ############
        btnCameraDecoder.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                Intent intent = new Intent(MainActivity.this, QRDecoderActivity.class);
                FirebaseUser user = mAuth.getCurrentUser();
                id = user.getUid();
                intent.putExtra("user_id",id.toString());
                MainActivity.this.startActivity(intent);
            }
        });
        // ############ MEUS EVENTOS ############
        btnMeusEventos.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                Intent intent = new Intent(MainActivity.this, MeusEventosActivity.class);
                FirebaseUser user = mAuth.getCurrentUser();
                id = user.getUid();
                intent.putExtra("user_id",id.toString());
                MainActivity.this.startActivity(intent);
            }
        });
        // ############ GERENCIAR CARTÕES ############
        btnGerenciarCartoes.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                Intent intent = new Intent(MainActivity.this, CartoesActivity.class);
                FirebaseUser user = mAuth.getCurrentUser();
                id = user.getUid();
                intent.putExtra("userSM", userSM);
                MainActivity.this.startActivity(intent);
            }
        });
    }

    @Override
    public void onStart()
    {
        super.onStart();
        // Check if user is signed in (non-null) and update UI accordingly.
        FirebaseUser currentUser = mAuth.getCurrentUser();
        updateUI();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        super.onActivityResult(requestCode, resultCode, data);
        // Pass the activity result back to the Facebook SDK
        mCallbackManager.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    protected void onDestroy()
    {
        super.onDestroy();
        mProfileTracker.stopTracking();
        btnLoginFB.unregisterCallback(mCallbackManager);
        //LoginManager.getInstance().unregisterCallback(callbackManager);
    }

    // ########## INÍCIO AUTENTICAÇÃO FACEBOOK ##########
    private void handleFacebookAccessToken(AccessToken token)
    {
//        String birthday ="";
        Log.d(TAG, "handleFacebookAccessToken:" + token);
        AuthCredential credential = FacebookAuthProvider.getCredential(token.getToken());

/*        new GraphRequest(AccessToken.getCurrentAccessToken(), "/{user-id}/{user-birthday}", null, HttpMethod.GET,
                new GraphRequest.Callback()
                {
                    @Override
                    public void onCompleted(GraphResponse response)
                    {
                        birthday = response.toString();
                    }
                }).executeAsync();*/

        if(AccessToken.getCurrentAccessToken()!=null)
        {
            GraphRequest request = GraphRequest.newMeRequest(AccessToken.getCurrentAccessToken(), new GraphRequest.GraphJSONObjectCallback()
            {
                @Override
                public void onCompleted(JSONObject object, GraphResponse response)
                {
                    try
                    {
                        birthday = object.getString("birthday");
                    } catch (JSONException e)
                    {
                        e.printStackTrace();
                    }
                }
            });
            Bundle parameters = new Bundle();
            parameters.putString("fields", "id,name,email,gender,birthday");
            request.setParameters(parameters);
            request.executeAsync();

        }
        mAuth.signInWithCredential(credential).addOnCompleteListener(this, new OnCompleteListener<AuthResult>()
        {

            @Override
            public void onComplete(@NonNull Task<AuthResult> task)
            {
                if (task.isSuccessful())
                {

                    // Sign in success, update UI with the signed-in user's information
                    Log.d(TAG, "signInWithCredential:success");
                    FirebaseUser user = mAuth.getCurrentUser();
                    updateUI();
                    createUserDB(user);
                }
                else
                {
                    // If sign in fails, display a message to the user.
                    Log.w(TAG, "signInWithCredential:failure", task.getException());
                    Toast.makeText(MainActivity.this, "Authentication failed.",
                            Toast.LENGTH_SHORT).show();
                    updateUI();
                }
                //hideProgressDialog();
            }
        });
    }

    public void signOut()
    {
        mAuth.signOut();
        LoginManager.getInstance().logOut();

        updateUI();
    }

    private void updateUI()
    {
        //hideProgressDialog();
        Profile profile = Profile.getCurrentProfile();

        if (profile != null)
        {
            imgProfileFB.setProfileId(profile.getId());
            btnListarEventos.setVisibility(View.VISIBLE);
            btnMeusEventos.setVisibility(View.VISIBLE);
            btnMeuQrCode.setVisibility(View.VISIBLE);
            btnCameraDecoder.setVisibility(View.VISIBLE);
            tvBemVindo.setText("Olá, "+profile.getFirstName()+"!");
            loadUserObject();
        }
        else
        {
            imgProfileFB.setProfileId(null);
            btnListarEventos.setVisibility(View.GONE);
            btnMeusEventos.setVisibility(View.GONE);
            btnMeuQrCode.setVisibility(View.GONE);
            btnCameraDecoder.setVisibility(View.GONE);
            tvBemVindo.setText("Para começar, conecte-se no Facebook:");
        }
    }
    private void createUserDB(FirebaseUser user)
    {
        TelephonyManager tMgr = (TelephonyManager)MainActivity.this.getSystemService(Context.TELEPHONY_SERVICE);

        number = tMgr.getLine1Number().toString();

        id = user.getUid();
        name = user.getDisplayName();
        email = user.getEmail();
        number = user.getPhoneNumber();
        provider = user.getProviderId();


        final Users userSM = new Users(id, name, birthday, email, provider, number);

        final DatabaseReference mRef = FirebaseDatabase.getInstance().getReference("users");
        mRef.addListenerForSingleValueEvent(new ValueEventListener()
        {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot)
            {
                if(!dataSnapshot.hasChild(id))
                {
                    mRef.child(id).setValue(userSM);
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError)
            {

            }
        });
    }

    private void loadUserObject()
    {
        FirebaseUser userFB = mAuth.getCurrentUser();
        userSM = new Users();
        id = userFB.getUid();
        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("users");
        ref = ref.child(id.toString());
        try
        {
            ref.addListenerForSingleValueEvent(new ValueEventListener()
            {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot)
                {
                    String a  = dataSnapshot.getKey();

                    for (DataSnapshot childs : dataSnapshot.getChildren())
                    {
                        if (childs.getKey().equals("name"))
                        {
                            userSM.setName(childs.getValue().toString());
                        }
                        if (childs.getKey().equals("email"))
                        {
                            userSM.setEmail(childs.getValue().toString());
                        }
                        if (childs.getKey().equals("cpf"))
                        {
                            userSM.setCpf(childs.getValue().toString());
                        }
                        if (childs.getKey().equals("birth"))
                        {
                            userSM.setBirth(childs.getValue().toString());
                        }
                        if (childs.getKey().equals("phone_number"))
                        {
                            userSM.setPhoneNumber(childs.getValue().toString());
                        }
                        if (childs.getKey().equals("provider"))
                        {
                            userSM.setProvider(childs.getValue().toString());
                        }
                        if (childs.getKey().equals("id"))
                        {
                            userSM.setId(childs.getValue().toString());
                        }
                    }
                }


                @Override
                public void onCancelled(DatabaseError databaseError)
                {

                }
            });
        }
        catch (Exception e)
        {
            Log.d("Erro", e.getMessage());
        }
//        return userSM;
    }

}
