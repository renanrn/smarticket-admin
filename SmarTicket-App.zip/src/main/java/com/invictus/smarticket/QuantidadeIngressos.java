package com.invictus.smarticket;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.DialogFragment;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

public class QuantidadeIngressos extends DialogFragment
{
    final CharSequence[] items = {"0", "1", "2", "3", "4", "5"};
    String selection;

    @NonNull
    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState)
    {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setTitle("Quantidade").setSingleChoiceItems(items, -1, new DialogInterface.OnClickListener()
        {
            @Override
            public void onClick(DialogInterface dialogInterface, int i)
            {
                switch (i)
                {
                    case 0:
                    case 1:
                    case 2:
                    case 3:
                    case 4:
                    case 5:
                        selection = (String) items[i];
                        ((CompraDetalhes) getActivity()).setarQuantidade(items[i].toString());
                        getDialog().dismiss();
                        break;
                    default:
                        break;
                }
            }
        });
        return builder.create();
    }
}
