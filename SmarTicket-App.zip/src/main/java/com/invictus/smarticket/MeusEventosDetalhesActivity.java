package com.invictus.smarticket;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.invictus.smarticket.classes.Cards;
import com.invictus.smarticket.classes.Events;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class MeusEventosDetalhesActivity extends AppCompatActivity
{

    private TextView txtTitleEvt;
    private Button btnPagarTodas;
    private DatabaseReference ref = FirebaseDatabase.getInstance().getReference();
    private DatabaseReference userRef = FirebaseDatabase.getInstance().getReference("users");
    private DatabaseReference cardsRef;
    private DatabaseReference cardsRefObj = FirebaseDatabase.getInstance().getReference("cards");
    private DatabaseReference itenssRef = FirebaseDatabase.getInstance().getReference("itens");
    private ProgressDialog pDialog;
    private ListView listV;
    private ArrayList<String> listIdCards = new ArrayList<>();
    private ArrayList<String> list = new ArrayList<>();
    private ArrayAdapter<String> adapter;
    private String userId, evtId, evtTitle, cardStatus, cardType;
    private Cards toCard;
    private ArrayList<String> listItens = new ArrayList<>();
    private ArrayList<String> listItensQtd = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_meus_eventos_detalhes);

        getSupportActionBar().hide();

        userId = getIntent().getExtras().getString("user_id");
        evtId = getIntent().getExtras().getString("evt_id");
        evtTitle = getIntent().getExtras().getString("evt_title");
        userRef = userRef.child(userId);

        pDialog = new ProgressDialog(this);
        pDialog.setTitle("Carregando comandas...");
        pDialog.show();

        txtTitleEvt = (TextView) findViewById(R.id.txtMyEvtTitle);
        btnPagarTodas = (Button) findViewById(R.id.btnPagarTodas);
        listV = (ListView) findViewById(R.id.listviewComandas);

        txtTitleEvt.setText(evtTitle);

        adapter = new ArrayAdapter<String>(this, R.layout.drawer_list_item, list);
        listV.setAdapter(adapter);

        loadCards();

        listV.setOnItemClickListener(new AdapterView.OnItemClickListener()
        {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id)
            {
                String cardId = list.get(position).toString();
                Intent intent = new Intent(MeusEventosDetalhesActivity.this, ComandaDetalheActivity.class);
                intent.putExtra("user_id", userId);
                intent.putExtra("evt_id", evtId);
                intent.putExtra("evt_title", evtTitle);
                intent.putExtra("card_id", cardId);

                MeusEventosDetalhesActivity.this.startActivity(intent);
            }
        });
    }

    private void loadCards()
    {
        final Map<String, String> mapCards = new HashMap();
        cardsRef = userRef.child("cards");
        cardsRef.addListenerForSingleValueEvent(new ValueEventListener()
        {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot)
            {
                for (DataSnapshot childs : dataSnapshot.getChildren())
                {
                    String key, value;
                    key = childs.getKey().toString();
                    mapCards.put(key, "");
                    listIdCards.add(key);
                }
                for (int i = 0; i <= listIdCards.size() - 1; i++)
                {
                    String cardKey = listIdCards.get(i);
                    cardsRef = ref.child("cards").child(cardKey);
                    cardsRef.push();

                    cardsRef.addListenerForSingleValueEvent(new ValueEventListener()
                    {
                        @Override
                        public void onDataChange(DataSnapshot dataSnapshot)
                        {
                            String evtIdCard = "", status = "", id = "";
                            for (DataSnapshot childs : dataSnapshot.getChildren())
                            {
                                if (childs.getKey().toString().equals("event"))
                                {
                                    evtIdCard = childs.getValue().toString();
                                }
                                if (childs.getKey().toString().equals("status"))
                                {
                                    status = childs.getValue().toString();
                                }
                                if (evtIdCard.equals(evtId) && status.equals("active"))
                                {
                                    list.add(dataSnapshot.getKey().toString());
                                    evtIdCard = "";
                                    status = "";
                                    adapter.notifyDataSetChanged();
                                }
                            }
                        }

                        @Override
                        public void onCancelled(DatabaseError databaseError)
                        {
                        }
                    });
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError)
            {
            }
        });
    }

    @Override
    protected void onResume()
    {
        pDialog.dismiss();
        super.onResume();
    }
}
