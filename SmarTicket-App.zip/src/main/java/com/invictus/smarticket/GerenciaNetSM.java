package com.invictus.smarticket;


import android.os.AsyncTask;
import android.util.Base64;
import android.util.Log;

import com.loopj.android.http.AsyncHttpClient;

import org.json.JSONObject;

import java.io.BufferedOutputStream;
import java.io.BufferedWriter;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.util.List;
import java.util.Objects;

/**
 * Created by renan on 19/10/17.
 */

public class GerenciaNetSM
{
    private WebService ws = new WebService();
    private JSONObject credentials = new JSONObject();
    private JSONObject headers = new JSONObject();
    private JSONObject data = new JSONObject();
    URI url;

    public JSONObject authorize()
    {
        try
        {
            url = new URI("https://sandbox.gerencianet.com.br/v1/authorize");
            credentials.put("client_id", "Client_Id_0bac5973bde403a31c9618f3877dfcd3182a28a7");
            credentials.put("client_secret", "Client_Secret_212163ed29c78a8da6af4a8cbb403fc293202f69");

            String token = credentials.get("client_id").toString();
            token += ":";
            token += credentials.get("client_secret").toString();

            byte[] tokenBytesEncoded = token.getBytes("UTF-8");
            String tokenBase64 = Base64.encodeToString(tokenBytesEncoded, Base64.DEFAULT);

            data.put("grant_type", "client_credentials");

            headers.put("api-sdk", "python-1.0.7");
            headers.put("Authorization", "Basic " + tokenBase64);
            String a = "";

//            ws.Synchronize("http://192.168.1.14:5000", "tokenRenanzinho", this);
//            List<NameV>

//            CallApi.execute();
        }
        catch (Exception e)
        {
            Log.i("NaoPASSEI", "Algo errado: " + e.getMessage());
        }

        return headers;
    }

/*    public class CallApi extends AsyncTask<String, String, String>
    {
        @Override
        protected void onPreExecute()
        {
            super.onPreExecute();
        }

        @Override
        protected void onPostExecute(String s)
        {
            super.onPostExecute(s);
        }

        @Override
        protected String doInBackground(String... params)
        {
            String urlString = params[0]; // URL to call

            String data = params[1]; //data to post
            String headers = params[2]; //headers to post
            String urlString = params[0]; // URL to call

            String data = params[1]; //data to post

            OutputStream out = null;
            try
            {

                URL url = new URL(urlString);

                HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();

                out = new BufferedOutputStream(urlConnection.getOutputStream());

                BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(out, "UTF-8"));

                writer.write(data);

                writer.flush();

                writer.close();

                out.close();

                urlConnection.connect();

            }
            catch (Exception e)
            {

                System.out.println(e.getMessage());

            }

            return null;
        }
    }*/
}
