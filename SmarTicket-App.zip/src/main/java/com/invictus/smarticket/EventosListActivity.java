package com.invictus.smarticket;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.invictus.smarticket.classes.Events;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class EventosListActivity extends AppCompatActivity
{
    private static final String TAG = "ListAct-Renan";
    private ProgressDialog dialog;
    private ListView listV;
    private ArrayList<String> list = new ArrayList<>();
    private Map<String, String> map = new HashMap<>();
    private ArrayAdapter<String> adapter;
    private Events event = new Events();
    private DatabaseReference mRef;
    private DatabaseReference novaRef;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_eventos_list);
        listV = (ListView) findViewById(R.id.listview);
        getSupportActionBar().hide();

        dialog = new ProgressDialog(EventosListActivity.this);
        dialog.setMessage("Carregando eventos...");
        dialog.show();

        mRef = FirebaseDatabase.getInstance().getReference();
        novaRef = mRef.getDatabase().getReference("events");

        adapter = new ArrayAdapter<String>(this, R.layout.drawer_list_item, list);
        listV.setAdapter(adapter);

        Query query = novaRef.orderByKey();

        query.addChildEventListener(new ChildEventListener()
        {
            @Override
            public void onChildAdded (DataSnapshot dataSnapshot, String s)
            {
                Log.i("FIREBASE",dataSnapshot.getValue().toString());
                for (DataSnapshot childs : dataSnapshot.getChildren())
                {
                    if (childs.getKey().equals("title"))
                    {
                        event.setTitle(childs.getValue().toString());
                        list.add(event.getTitle());
                        adapter.notifyDataSetChanged();
                    }
                    if (childs.getKey().equals("id"))
                    {
                        event.setId(childs.getValue().toString());
                    }

                    if(event.getId() != null && event.getTitle() != null)
                    {
                        map.put(event.getId(), event.getTitle());
                    }
                }
            }

            @Override
            public void onChildRemoved(DataSnapshot dataSnapshot)
            {
                for (DataSnapshot childs : dataSnapshot.getChildren())
                {
                    if (childs.getKey().equals("title"))
                    {
                        list.remove(childs.getValue());
                        adapter.notifyDataSetChanged();
                    }
                    if (childs.getKey().equals("id"))
                    {
                        map.remove(childs.getValue().toString());
                    }
                }
            }

            @Override
            public void onChildChanged(DataSnapshot dataSnapshot, String s) {}
            @Override
            public void onChildMoved(DataSnapshot dataSnapshot, String s) {}
            @Override
            public void onCancelled(DatabaseError databaseError) {}
        });


        listV.setOnItemClickListener(new AdapterView.OnItemClickListener()
        {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l)
            {
                Query qr = novaRef.equalTo(adapter.getItem(i));
                String pos = "";

                for (Map.Entry<String, String> entry : map.entrySet())
                {
                    if (entry.getValue().equals(adapter.getItem(i)))
                    {
                        pos = entry.getKey().toString();
                        Log.i("FIREBASE", pos);
                    }
                }
                Intent activityChangeIntent = new Intent(EventosListActivity.this, EventosDetalhesActivity.class);
                activityChangeIntent.putExtra("id_evt", pos);
                EventosListActivity.this.startActivity(activityChangeIntent);
            }
        });
    }

    @Override
    protected void onResume()
    {
        dialog.dismiss();
        super.onResume();
    }

    public class ListEventsAsync extends AsyncTask<Void, Void, Void>
    {

        @Override
        protected void onPreExecute()
        {
            super.onPreExecute();
        }

        @Override
        protected void onPostExecute(Void aVoid)
        {
            super.onPostExecute(aVoid);
        }

        @Override
        protected Void doInBackground(Void... voids)
        {
            return null;
        }
    }


}
