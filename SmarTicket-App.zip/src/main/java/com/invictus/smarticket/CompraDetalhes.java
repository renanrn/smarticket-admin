package com.invictus.smarticket;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Color;
import android.os.AsyncTask;
import android.support.v4.app.FragmentActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.gson.Gson;
import com.invictus.smarticket.classes.BillingAddress;
import com.invictus.smarticket.classes.CreditCards;
import com.invictus.smarticket.classes.Events;
import com.invictus.smarticket.classes.Itens;
import com.invictus.smarticket.classes.Users;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import br.com.gerencianet.gnsdk.config.Config;
import br.com.gerencianet.gnsdk.interfaces.IGnListener;
import br.com.gerencianet.gnsdk.lib.Endpoints;
import br.com.gerencianet.gnsdk.models.CreditCard;
import br.com.gerencianet.gnsdk.models.Error;
import br.com.gerencianet.gnsdk.models.Installment;
import br.com.gerencianet.gnsdk.models.PaymentData;
import br.com.gerencianet.gnsdk.models.PaymentToken;

public class CompraDetalhes extends FragmentActivity implements IGnListener
{
    private Users userSM = new Users();
    private CreditCards cardSMart = new CreditCards();
    private String evtSM = new String();
    //    private CreditCards cardSM = new CreditCards();
    private Config config;
    private Endpoints gnClient;
    private CreditCard creditCard;
    private io.socket.client.Socket socket = null;
    private TextView txtQuantidade, txtValorIngresso, txtTituloEvt, txtTotal;
    private TextView txtResponse;
    private Button btnPagar;
    private String idUser, idEvt, precoCons, GNAccountCode, quantidadeCons = "0", billingAddress;
    private double finalPrice;
    private DatabaseReference mRef = FirebaseDatabase.getInstance().getReference("events");
    private DatabaseReference userRef = FirebaseDatabase.getInstance().getReference("users");
    private DatabaseReference evtRef, billingRef, ccRef;
    private FirebaseAuth mAuth;
    private WebService ws = new WebService();
    Map<String, String> params = new HashMap<String, String>();
    Map<Object, CharSequence[]> itens = new HashMap<>();
    CharSequence[] teste;
    List<CreditCards> card = new ArrayList<>();
    private Context context;
    private ProgressDialog pDialog;
    private Gson gson = new Gson();


    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_compra_detalhes);
        context = this;
        idEvt = getIntent().getExtras().getString("id_evt");

        pDialog = new ProgressDialog(context);
        pDialog.setTitle("Carregando...");

        txtQuantidade = (TextView) findViewById(R.id.txtQuantidade);
        txtValorIngresso = (TextView) findViewById(R.id.txtValorIngresso);
        txtTituloEvt = (TextView) findViewById(R.id.txtTituloEvt);
        txtTotal = (TextView) findViewById(R.id.txtTotal);
        txtResponse = (TextView) findViewById(R.id.response_text);
        btnPagar = (Button) findViewById(R.id.btnPagar);

//        ########## GerenciaNet
        GNAccountCode = getResources().getString(R.string.gn_account_code);
        config = new Config();
        config.setAccountCode(GNAccountCode);
        config.setSandbox(true);
        gnClient = new Endpoints(config, this);

        mAuth = FirebaseAuth.getInstance();

        FirebaseUser user = mAuth.getCurrentUser();
        idUser = user.getUid();
        userSM.setId(idUser);

        userRef = userRef.child(idUser);
        userRef.addListenerForSingleValueEvent(new ValueEventListener()
        {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot)
            {
                for (DataSnapshot childs : dataSnapshot.getChildren())
                {
                    if (childs.getKey().equals("name"))
                    {
                        userSM.setName(childs.getValue().toString());
                    }
                    if (childs.getKey().equals("email"))
                    {
                        userSM.setEmail(childs.getValue().toString());
                    }
                    if (childs.getKey().equals("cpf"))
                    {
                        userSM.setCpf(childs.getValue().toString());
                    }
                    if (childs.getKey().equals("birth"))
                    {
                        userSM.setBirth(childs.getValue().toString());
                    }
                    if (childs.getKey().equals("phone_number"))
                    {
                        userSM.setPhoneNumber(childs.getValue().toString());
                    }
                    if (childs.getKey().equals("provider"))
                    {
                        userSM.setProvider(childs.getValue().toString());
                    }
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError)
            {
            }
        });
        billingRef = userRef.child("billing_address");
        billingRef.addListenerForSingleValueEvent(new ValueEventListener()
        {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot)
            {
                for (DataSnapshot childs : dataSnapshot.getChildren())
                {
                    if (childs.getKey().equals("street"))
                    {
                        userSM.getBillingAddress().setStreet(childs.getValue().toString());
                    }
                    if (childs.getKey().equals("number"))
                    {
                        userSM.getBillingAddress().setNumber(childs.getValue().toString());
                    }
                    if (childs.getKey().equals("neighborhood"))
                    {
                        userSM.getBillingAddress().setNeighborhood(childs.getValue().toString());
                    }
                    if (childs.getKey().equals("zipcode"))
                    {
                        userSM.getBillingAddress().setZipcode(childs.getValue().toString());
                    }
                    if (childs.getKey().equals("city"))
                    {
                        userSM.getBillingAddress().setCity(childs.getValue().toString());
                    }
                    if (childs.getKey().equals("state"))
                    {
                        userSM.getBillingAddress().setState(childs.getValue().toString());
                    }
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError)
            {
            }
        });

//        ################################################################### Mapeando o cartao de crédito ########################################
        ccRef = userRef.child("credit_cards");
        ccRef.addListenerForSingleValueEvent(new ValueEventListener()
        {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot)
            {

                String brand = "", number = "", lineCC = "";
                for (DataSnapshot ds : dataSnapshot.getChildren())
                {
                    CreditCards cardSM = new CreditCards();
                    for (DataSnapshot childs : ds.getChildren())
                    {
                        if (childs.getKey().equals("brand"))
                        {
                            brand = childs.getValue().toString();
                            cardSM.setBrand(brand);
                        }
                        if (childs.getKey().equals("number"))
                        {
                            number = childs.getValue().toString();
                            cardSM.setNumber(number);
                            number = number.substring(number.length() - 4, number.length());
                            number = "#### #### #### " + number;
                        }
                        if (childs.getKey().equals("cvv"))
                        {
                            cardSM.setCvv(childs.getValue().toString());
                        }
                        if (childs.getKey().equals("expirationMonth"))
                        {
                            cardSM.setExpirationMonth(childs.getValue().toString());
                        }
                        if (childs.getKey().equals("expirationYear"))
                        {
                            cardSM.setExpirationYear(childs.getValue().toString());
                        }
                        if (brand.length() > 0 && number.length() > 0)
                        {
                            lineCC = brand + " - " + number;
                        }

                    }
                    card.add(cardSM);
                }
                userSM.setCreditCards(card);
            }

            @Override
            public void onCancelled(DatabaseError databaseError)
            {

            }
        });

        idEvt = getIntent().getExtras().getString("id_evt");
        evtRef = mRef.child(idEvt);
        evtRef.addListenerForSingleValueEvent(new ValueEventListener()
        {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot)
            {
                txtTituloEvt.setText(String.valueOf(dataSnapshot.child("title").getValue()));

                String price = String.valueOf(dataSnapshot.child("price").getValue());

                if (!price.equals("null"))
                {
                    precoCons = price;
                    double pricef = Double.parseDouble(price);

                    txtValorIngresso.setText("R$ " + new DecimalFormat("#,##0.00").format(pricef) + " cada");
                }
                else precoCons = "0";

            }

            @Override
            public void onCancelled(DatabaseError databaseError)
            {

            }
        });
    }

    public void escolherQuantidade(View v)
    {
        QuantidadeIngressos my_dialog = new QuantidadeIngressos();
        my_dialog.show(getSupportFragmentManager(), "my_dialog");

    }

    public void setarQuantidade(String qt)
    {
        quantidadeCons = qt;
        finalPrice = Double.parseDouble(qt) * Double.parseDouble(precoCons);
        String formatedPrice = new DecimalFormat("#,##0.00").format(finalPrice);
        txtQuantidade.setText("0" + qt + " - R$ " + formatedPrice);

        finalPrice = finalPrice * 1.10;
        formatedPrice = new DecimalFormat("#,##0.00").format(finalPrice);
        txtTotal.setText("R$ " + formatedPrice);

        if (qt != "0")
        {
            btnPagar.setEnabled(true);
            btnPagar.setTextColor(Color.parseColor("#E2E2F9"));
        }
        else
        {
            btnPagar.setEnabled(false);
            btnPagar.setTextColor(Color.parseColor("#7f7f7f"));
        }
    }

    public void pagar(View v)
    {
            ArrayList<String> array = new ArrayList<>();
            for (int i = 0; i < userSM.getCreditCards().size(); i++)
            {
                array.add(userSM.getCreditCards().get(i).getBrandNumberFormat());
            }
            CharSequence[] itens = array.toArray(new CharSequence[array.size()]);

            LayoutInflater inflater = CompraDetalhes.this.getLayoutInflater();
            View vv = inflater.inflate(R.layout.fragment_quantidade_ingressos, null);
            AlertDialog.Builder builder = new AlertDialog.Builder(CompraDetalhes.this);
            builder.setView(vv);
        builder.setTitle("Escolha o cartão")
                .setSingleChoiceItems(itens, -1, new DialogInterface.OnClickListener()
                {
                    @Override
                    public void onClick(DialogInterface dialog, int i)
                    {
                        try
                        {
                            userSM.getCreditCards();
                            String formatedPrice = new DecimalFormat("0.00").format(finalPrice / Integer.parseInt(quantidadeCons));

                            // Item único (Evento), então o Objeto é preenchido na hora para gerar o JSON.
                            Itens item = new Itens();
                            item.setName(txtTituloEvt.getText().toString());
                            item.setAmount(Integer.parseInt(quantidadeCons));
                            item.setValue(Double.parseDouble(formatedPrice));

                            // Inserindo parâmetros dos itens (nesse caso, somente o ingresso)
                            params.put("Items", gson.toJson(item));

                    /*String number = "4012001037141112";
                    String cvv = "123";
                    String month = "05";
                    String year = "2018";*/
                            String number = userSM.getCreditCards().get(i).getNumber();
                            String cvv = userSM.getCreditCards().get(i).getCvv();
                            String month = userSM.getCreditCards().get(i).getExpirationMonth();
                            String year = userSM.getCreditCards().get(i).getExpirationYear();
                            String brand = userSM.getCreditCards().get(i).getBrand();

                            if (number.matches("") || cvv.matches("") || month.matches("") || year.matches(""))
                            {
                                return;
                            }
                            creditCard = new CreditCard();
                            creditCard.setCvv(cvv);
                            creditCard.setNumber(number);
                            creditCard.setExpirationMonth(month);
                            creditCard.setExpirationYear("20" + year);
                            creditCard.setBrand(brand.toLowerCase());

                            gnClient.getPaymentToken(creditCard);

                            dialog.dismiss();
                            pDialog.show();

                        }
                        catch (Exception e)
                        {
                        }
                    }
                });
        builder.show();
    }

    @Override
    public void onInstallmentsFetched(PaymentData paymentData)
    {
        ArrayList<Installment> installments = (ArrayList<Installment>) paymentData.getInstallments();
        for (Installment installment : installments)
        {
            Log.e("GerenciaNet Response: ", installment.getValue().toString());
        }
    }

    @Override
    public void onPaymentTokenFetched(PaymentToken paymentToken)
    {
        pDialog.dismiss();
        View view = findViewById(R.id.response_layout);
        view.setVisibility(View.VISIBLE);

        txtResponse.setText("GerenciaNet Payment token: " + paymentToken.getHash());

        // Inserindo parâmetros do token
        params.put("payment_token", paymentToken.getHash());
        // Inserindo parâmetros do usuário
        params.put("user", gson.toJson(userSM));

        // Inserindo parâmetros do endereço
        BillingAddress ba = new BillingAddress();
        ba = userSM.getBillingAddress();
        params.put("billing_address", gson.toJson(ba));

        sendMessage(params);
    }

    @Override
    public void onError(Error error)
    {
        View view = findViewById(R.id.response_layout);
        view.setVisibility(View.VISIBLE);

        String errorMsg = "Code: " + error.getCode() + " Message: " + error.getMessage();

        TextView textView = (TextView) findViewById(R.id.response_text);
        textView.setText(errorMsg);
    }

    private void sendMessage(Map<String, String> params)
    {
        try
        {

            JSONObject jj = new JSONObject();
            PagarWS pagar = new PagarWS();
            jj = pagar.execute().get();

            ComprasConfirmacaoFragment my_dialog = new ComprasConfirmacaoFragment();
            my_dialog.show(getSupportFragmentManager(), "my_dialog");

            gravarEvento();
        }
        catch (Exception e)
        {
            Log.d("ErroWS", "Erro no WebService: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public void gravarEvento()
    {

        String key = idEvt;

        Map<String, Object> childUpdates = new HashMap<>();
        childUpdates.put("/events/" + key, "true");

        userRef.updateChildren(childUpdates);
    }

    @Override
    protected void onDestroy()
    {
        super.onDestroy();

        if (socket != null)
            socket.disconnect();
    }

    private class PagarWS extends AsyncTask<Void, Void, JSONObject>
    {
        ProgressDialog dialog;
        JSONObject resp = new JSONObject();
        String URL_ws = "http://192.168.1.16:5000";
        Map<String, String> params_ws = params;

        @Override
        protected void onPreExecute()
        {
            dialog = new ProgressDialog(context);
            dialog.setTitle("Carregando...");
            dialog.show();
            super.onPreExecute();
        }

        @Override
        protected void onPostExecute(JSONObject jsonObject)
        {
            dialog.dismiss();
            super.onPostExecute(jsonObject);
        }

        @Override
        protected JSONObject doInBackground(Void... voids)
        {
            String url = URL_ws;

            StringRequest postRequest = new StringRequest(Request.Method.POST, url,
                    new Response.Listener<String>()
                    {
                        @Override
                        public void onResponse(String response)
                        {
                            try
                            {
                                JSONObject jsonResponse = new JSONObject(response);
                                resp = new JSONObject(response);
                                Log.d("JSON", "JSON Response: " + jsonResponse.toString());

                            }
                            catch (JSONException e)
                            {
                                e.printStackTrace();
                            }
                        }
                    },
                    new Response.ErrorListener()
                    {
                        @Override
                        public void onErrorResponse(VolleyError error)
                        {
                            error.printStackTrace();
                        }
                    }
            )
            {

                @Override
                protected Map<String, String> getParams()
                {
                    return params_ws;
                }
            };
            MySingleton.getInstance(context).addToRequestQueue(postRequest);
//            Volley.newRequestQueue(context).add(postRequest);
            return resp;
        }
    }

}
